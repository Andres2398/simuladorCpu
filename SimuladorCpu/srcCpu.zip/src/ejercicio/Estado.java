package ejercicio;
/**
 * Clase enum con todos los estados disponibles de los procesos
 */
public enum Estado {
	LISTO, BLOQUEADO, EJECUTANDO, TERMINADO

}
